import type {Result, Option} from './support'

export interface AccountData {
    free: bigint
    reserved: bigint
    miscFrozen: bigint
    feeFrozen: bigint
}

export interface AccountInfo {
    nonce: bigint
    consumers: number
    providers: number
    sufficients: number
    data: AccountData
}
