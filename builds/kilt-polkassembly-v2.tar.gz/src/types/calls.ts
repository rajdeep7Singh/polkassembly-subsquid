export * as democracy from './democracy/calls'
export * as tips from './tips/calls'
