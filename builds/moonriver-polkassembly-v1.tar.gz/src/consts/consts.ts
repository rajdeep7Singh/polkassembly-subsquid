export const PERIOD = 1000 * 60 * 60 * 12
export const REDIS_CF_URL = 'https://europe-west1-individual-node-watcher.cloudfunctions.net/deleteKey'
export const NOTIFICATION_URL = 'https://us-central1-polkasafe-a8042.cloudfunctions.net/notify'