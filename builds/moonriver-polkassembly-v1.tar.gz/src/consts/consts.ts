export const PERIOD = 1000 * 60 * 60 * 12
export const REDIS_CF_URL = 'https://europe-west1-individual-node-watcher.cloudfunctions.net/deleteKey'
export const NOTIFICATION_URL = 'https://us-central1-polkasafe-a8042.cloudfunctions.net/notify'
export const PRECOMPILES = ['0x0000000000000000000000000000000000000803', '0x0000000000000000000000000000000000000812', '0x0000000000000000000000000000000000000808', '0x000000000000000000000000000000000000080b']