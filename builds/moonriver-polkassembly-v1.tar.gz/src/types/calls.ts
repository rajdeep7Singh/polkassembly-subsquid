export * as ethereum from './ethereum/calls'
export * as democracy from './democracy/calls'
export * as convictionVoting from './conviction-voting/calls'
