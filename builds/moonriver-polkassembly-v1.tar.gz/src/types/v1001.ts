import {sts, Result, Option, Bytes, BitSequence} from './support'

export const AccountId20 = sts.bytes()
