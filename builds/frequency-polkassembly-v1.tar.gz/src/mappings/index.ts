import democracy from './democracy'
import council from './council'
import treasury from './treasury'
import techComittee from './techCommittee'
import preimageV2 from './preimageV2'

export { democracy, council, treasury, techComittee, preimageV2}
