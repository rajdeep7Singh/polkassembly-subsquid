import * as council from './council'
import * as democracy from './democracy'
import * as treasury from './treasury'

export const storage = {
    council,
    democracy,
    treasury
}
