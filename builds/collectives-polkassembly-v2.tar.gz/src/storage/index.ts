import * as allianceMotion from './allianceMotion'
// import * as techCommittee from './techCommittee'
// import * as treasury from './treasury'
// import * as tips from './tips'
// import * as bounties from './bounties'
// import * as childBounties from './childBounties'

export const storage = {
    allianceMotion
//     techCommittee,
//     democracy,
//     treasury,
//     bounties,
//     tips,
//     childBounties,
}
