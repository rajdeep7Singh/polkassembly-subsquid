from sortedcontainers import SortedList

class MyCalender:
    def __init__(self):
        self.calendars = SortedList()
    
    def book(self, start, end):
        index = self.calendars.bisect_left((start, end))
        
        if index - 1 >= 0 and self.calendars[index][1] > start:
            return False
        
        if index < len(self.calendars) and self.calendars[index][0] < end:
            return False
        
        self.calendars.add((start, end))
        return True



a = MyCalender()
# print(a.book(10, 20))
# print(a.book(30, 40))
# print(a.book(15, 40))

a.book(20, 25)
a.book(15, 25)
a.book(10, 20)
a.book(11, 12)
a.book(30, 40)