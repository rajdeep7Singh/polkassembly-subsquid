import * as events from './events'
import * as extrinsics from './extrinsics'

export default {
    events,
    extrinsics,
}