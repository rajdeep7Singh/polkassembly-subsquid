export { handleNewTipValue } from './new_tip_value'
export { handleNewTipValueOld } from './new_tip_value'

