export enum ProposalType {
    TechnicalCommittee = "TechnicalCommittee",
    UpgradeCommittee = "UpgradeCommittee",
    Community = "Community",
}
