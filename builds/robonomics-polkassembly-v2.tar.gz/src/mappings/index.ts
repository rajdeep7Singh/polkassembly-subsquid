import democracy from './democracy'
import treasury from './treasury'
import techComittee from './techCommittee'
import preimageV2 from './preimageV2'

export { democracy, treasury, techComittee, preimageV2 }
