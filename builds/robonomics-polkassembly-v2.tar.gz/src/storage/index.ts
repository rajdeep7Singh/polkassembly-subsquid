import * as democracy from './democracy'
import * as techCommittee from './techCommittee'
import * as treasury from './treasury'

export const storage = {
    techCommittee,
    democracy,
    treasury
}
