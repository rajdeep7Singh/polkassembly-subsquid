export enum VoteType {
    AllianceMotion = "AllianceMotion",
}
