import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_, ManyToOne as ManyToOne_, Index as Index_} from "typeorm"
import * as marshal from "./marshal"
import {Proposal} from "./proposal.model"
import {VoteDecision} from "./_voteDecision"
import {VoteBalance, fromJsonVoteBalance} from "./_voteBalance"

@Entity_()
export class Vote {
    constructor(props?: Partial<Vote>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Column_("text", {nullable: true})
    voter!: string | undefined | null

    @Index_()
    @ManyToOne_(() => Proposal, {nullable: true})
    proposal!: Proposal

    @Column_("int4", {nullable: false})
    proposalIndex!: number

    @Index_()
    @Column_("int4", {nullable: false})
    blockNumber!: number

    @Index_()
    @Column_("timestamp with time zone", {nullable: false})
    timestamp!: Date

    @Column_("varchar", {length: 12, nullable: true})
    decision!: VoteDecision | undefined | null

    @Column_("jsonb", {transformer: {to: obj => obj == null ? undefined : obj.toJSON(), from: obj => obj == null ? undefined : fromJsonVoteBalance(obj)}, nullable: true})
    balance!: VoteBalance | undefined | null

    @Column_("int4", {nullable: true})
    lockPeriod!: number | undefined | null

    @Column_("text", {nullable: true})
    identityId!: string | undefined | null

    @Column_("int4", {nullable: true})
    removedAtBlock!: number | undefined | null

    @Column_("timestamp with time zone", {nullable: true})
    removedAt!: Date | undefined | null
}
