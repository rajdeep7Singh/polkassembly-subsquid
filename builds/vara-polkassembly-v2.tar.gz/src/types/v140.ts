import {sts, Result, Option, Bytes, BitSequence} from './support'

export const H256 = sts.bytes()
