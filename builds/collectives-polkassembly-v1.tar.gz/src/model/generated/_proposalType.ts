export enum ProposalType {
    AllianceMotion = "AllianceMotion",
    Announcement = "Announcement",
    UnscrupulousItem = "UnscrupulousItem",
    FellowshipReferendum = "FellowshipReferendum",
}
