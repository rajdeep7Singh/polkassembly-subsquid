import * as treasury from './treasury'

export const storage = {
    treasury
}
