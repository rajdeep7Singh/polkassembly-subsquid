export enum VoteType {
  Referendum = "Referendum",
  Motion = "Motion",
  ReferendumV2 = "ReferendumV2",
  Fellowship = "Fellowship",
}
