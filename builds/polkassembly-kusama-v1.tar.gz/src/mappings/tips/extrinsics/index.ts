export { handleNewTipValue } from './new_tip_value'
