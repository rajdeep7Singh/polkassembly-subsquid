export enum DelegationType {
    OpenGov = "OpenGov",
    Democracy = "Democracy",
}
