export enum VoteType {
    AllianceMotion = "AllianceMotion",
    Fellowship = "Fellowship",
    Referendum = "Referendum",
}
