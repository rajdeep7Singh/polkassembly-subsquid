export enum VoteDecision {
  yes = "yes",
  no = "no",
  abstain = "abstain",
  split = "split",
  splitAbstain = "splitAbstain",
}
