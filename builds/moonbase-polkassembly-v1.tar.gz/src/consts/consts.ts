export const PERIOD = 1000 * 60 * 60 * 12
export const REDIS_CF_URL = 'https://europe-west1-individual-node-watcher.cloudfunctions.net/deleteKey'