export const PERIOD = 1000 * 60 * 60 * 12
