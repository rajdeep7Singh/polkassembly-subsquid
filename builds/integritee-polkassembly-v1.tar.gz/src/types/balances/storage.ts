import {sts, Block, Bytes, Option, Result, StorageType, RuntimeCtx} from '../support'
import * as v3 from '../v3'
import * as v35 from '../v35'

export const totalIssuance =  {
    /**
     *  The total units issued in the system.
     */
    v3: new StorageType('Balances.TotalIssuance', 'Default', [], sts.bigint()) as TotalIssuanceV3,
}

/**
 *  The total units issued in the system.
 */
export interface TotalIssuanceV3  {
    is(block: RuntimeCtx): boolean
    getDefault(block: Block): bigint
    get(block: Block): Promise<(bigint | undefined)>
}

export const account =  {
    /**
     *  The balance of an account.
     * 
     *  NOTE: This is only used in the case that this pallet is used to store balances.
     */
    v3: new StorageType('Balances.Account', 'Default', [v3.AccountId32], v3.AccountData) as AccountV3,
    /**
     *  The Balances pallet example of storing the balance of an account.
     * 
     *  # Example
     * 
     *  ```nocompile
     *   impl pallet_balances::Config for Runtime {
     *     type AccountStore = StorageMapShim<Self::Account<Runtime>, frame_system::Provider<Runtime>, AccountId, Self::AccountData<Balance>>
     *   }
     *  ```
     * 
     *  You can also store the balance of an account in the `System` pallet.
     * 
     *  # Example
     * 
     *  ```nocompile
     *   impl pallet_balances::Config for Runtime {
     *    type AccountStore = System
     *   }
     *  ```
     * 
     *  But this comes with tradeoffs, storing account balances in the system pallet stores
     *  `frame_system` data alongside the account data contrary to storing account balances in the
     *  `Balances` pallet, which uses a `StorageMap` to store balances data only.
     *  NOTE: This is only used in the case that this pallet is used to store balances.
     */
    v35: new StorageType('Balances.Account', 'Default', [v35.AccountId32], v35.AccountData) as AccountV35,
}

/**
 *  The balance of an account.
 * 
 *  NOTE: This is only used in the case that this pallet is used to store balances.
 */
export interface AccountV3  {
    is(block: RuntimeCtx): boolean
    getDefault(block: Block): v3.AccountData
    get(block: Block, key: v3.AccountId32): Promise<(v3.AccountData | undefined)>
    getMany(block: Block, keys: v3.AccountId32[]): Promise<(v3.AccountData | undefined)[]>
    getKeys(block: Block): Promise<v3.AccountId32[]>
    getKeys(block: Block, key: v3.AccountId32): Promise<v3.AccountId32[]>
    getKeysPaged(pageSize: number, block: Block): AsyncIterable<v3.AccountId32[]>
    getKeysPaged(pageSize: number, block: Block, key: v3.AccountId32): AsyncIterable<v3.AccountId32[]>
    getPairs(block: Block): Promise<[k: v3.AccountId32, v: (v3.AccountData | undefined)][]>
    getPairs(block: Block, key: v3.AccountId32): Promise<[k: v3.AccountId32, v: (v3.AccountData | undefined)][]>
    getPairsPaged(pageSize: number, block: Block): AsyncIterable<[k: v3.AccountId32, v: (v3.AccountData | undefined)][]>
    getPairsPaged(pageSize: number, block: Block, key: v3.AccountId32): AsyncIterable<[k: v3.AccountId32, v: (v3.AccountData | undefined)][]>
}

/**
 *  The Balances pallet example of storing the balance of an account.
 * 
 *  # Example
 * 
 *  ```nocompile
 *   impl pallet_balances::Config for Runtime {
 *     type AccountStore = StorageMapShim<Self::Account<Runtime>, frame_system::Provider<Runtime>, AccountId, Self::AccountData<Balance>>
 *   }
 *  ```
 * 
 *  You can also store the balance of an account in the `System` pallet.
 * 
 *  # Example
 * 
 *  ```nocompile
 *   impl pallet_balances::Config for Runtime {
 *    type AccountStore = System
 *   }
 *  ```
 * 
 *  But this comes with tradeoffs, storing account balances in the system pallet stores
 *  `frame_system` data alongside the account data contrary to storing account balances in the
 *  `Balances` pallet, which uses a `StorageMap` to store balances data only.
 *  NOTE: This is only used in the case that this pallet is used to store balances.
 */
export interface AccountV35  {
    is(block: RuntimeCtx): boolean
    getDefault(block: Block): v35.AccountData
    get(block: Block, key: v35.AccountId32): Promise<(v35.AccountData | undefined)>
    getMany(block: Block, keys: v35.AccountId32[]): Promise<(v35.AccountData | undefined)[]>
    getKeys(block: Block): Promise<v35.AccountId32[]>
    getKeys(block: Block, key: v35.AccountId32): Promise<v35.AccountId32[]>
    getKeysPaged(pageSize: number, block: Block): AsyncIterable<v35.AccountId32[]>
    getKeysPaged(pageSize: number, block: Block, key: v35.AccountId32): AsyncIterable<v35.AccountId32[]>
    getPairs(block: Block): Promise<[k: v35.AccountId32, v: (v35.AccountData | undefined)][]>
    getPairs(block: Block, key: v35.AccountId32): Promise<[k: v35.AccountId32, v: (v35.AccountData | undefined)][]>
    getPairsPaged(pageSize: number, block: Block): AsyncIterable<[k: v35.AccountId32, v: (v35.AccountData | undefined)][]>
    getPairsPaged(pageSize: number, block: Block, key: v35.AccountId32): AsyncIterable<[k: v35.AccountId32, v: (v35.AccountData | undefined)][]>
}

export const inactiveIssuance =  {
    /**
     *  The total units of outstanding deactivated balance in the system.
     */
    v28: new StorageType('Balances.InactiveIssuance', 'Default', [], sts.bigint()) as InactiveIssuanceV28,
}

/**
 *  The total units of outstanding deactivated balance in the system.
 */
export interface InactiveIssuanceV28  {
    is(block: RuntimeCtx): boolean
    getDefault(block: Block): bigint
    get(block: Block): Promise<(bigint | undefined)>
}
