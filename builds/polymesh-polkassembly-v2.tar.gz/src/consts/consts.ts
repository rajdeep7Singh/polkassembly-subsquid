export const PERIOD = 1000 * 60 * 60 * 12
export const NOTIFICATION_URL = 'https://us-central1-polkasafe-a8042.cloudfunctions.net/notify'
