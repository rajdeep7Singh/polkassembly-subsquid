import * as pips from './pips'

export const storage = {
    pips
}
