export * as democracy from './democracy/calls'
export * as bounties from './bounties/calls'
export * as childBounties from './child-bounties/calls'
