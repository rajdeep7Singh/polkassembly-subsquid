import democracy from './democracy'
import council from './council'
import treasury from './treasury'
import bounties from './bounties'
import techComittee from './techCommittee'
import childBounties from './childBounties'
import preimageV2 from './preimageV2'

export { democracy, council, treasury, bounties, techComittee, childBounties, preimageV2 }
