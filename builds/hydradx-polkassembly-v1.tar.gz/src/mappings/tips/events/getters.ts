import { UnknownVersionError } from '../../../common/errors'
import {
    TipsNewTipEvent,
    TipsTipClosedEvent,
    TipsTipRetractedEvent,
    TipsTipSlashedEvent
} from '../../../types/events'
import { EventContext } from '../../types/contexts'
import { Event } from '../../../types/support'
import { BatchContext, SubstrateBlock } from '@subsquid/substrate-processor'
import { Store } from '@subsquid/typeorm-store'

interface ClosedData {
    hash: Uint8Array
    reward: bigint
}

export function getClosedData(ctx: BatchContext<Store, unknown>, itemEvent: Event): ClosedData {
    const event = new TipsTipClosedEvent(ctx, itemEvent)
    if (event.isV108) {
        const { tipHash: hash, payout: reward } = event.asV108
        return {
            hash,
            reward,
        }
    } else {
        throw new UnknownVersionError(event.constructor.name)
    }
}

interface NewTipData {
    hash: Uint8Array
}

export function getNewTipData(ctx: BatchContext<Store, unknown>, itemEvent: Event): NewTipData {
    const event = new TipsNewTipEvent(ctx, itemEvent)
    if (event.isV108) {
        const { tipHash: hash } = event.asV108
        return {
            hash,
        }
    } else {
        throw new UnknownVersionError(event.constructor.name)
    }
}

interface RectractedData {
    hash: Uint8Array
}

export function getRectractedData(ctx: BatchContext<Store, unknown>, itemEvent: Event): RectractedData {
    const event = new TipsTipRetractedEvent(ctx, itemEvent)
    if (event.isV108) {
        const { tipHash: hash } = event.asV108
        return {
            hash,
        }
    } else {
        throw new UnknownVersionError(event.constructor.name)
    }
}

interface SlashedData {
    hash: Uint8Array
}

export function getSlashedData(ctx: BatchContext<Store, unknown>, itemEvent: Event): SlashedData {
    const event = new TipsTipSlashedEvent(ctx, itemEvent)
    if (event.isV108) {
        const { tipHash: hash } = event.asV108
        return {
            hash,
        }
    } else {
        throw new UnknownVersionError(event.constructor.name)
    }
}
