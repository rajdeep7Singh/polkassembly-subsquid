export enum AnnouncementType {
    Account = "Account",
    Website = "Website",
    Announcement = "Announcement",
}
